<?php 
$nasa_args['is_deals'] = ($type == 'deals') ? true : false;
nasa_template('products/globals/row_layout.php', $nasa_args);
